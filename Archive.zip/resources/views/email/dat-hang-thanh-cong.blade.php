<h2>Chúng tôi chúc mừng bạn đã đặt hàng thành công</h2>
<p> Chúng tôi sẽ xem xét và phản hồi cho bạn nhanh nhất có thể</p>
<p>Kính chào và hẹn gặp lại. Good bye</p>