@extends('layouts.master')

@section('title', 'SB Admin 2')


@section('content')
<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="row ">
        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-4  col-12 card-table ">
            <div class="card  shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-dark text-uppercase mb-1">
                                <h5>Liên kết giới thiệu của bạn</h5>
                            </div>
                            <div class="form-group mb-4 form-click-to-copy-text">
                                <input id="copyInput" class="form-control" type="text" onclick="copyFunct()" value="{{url('/dang-ki')}}/{{Auth::user()->id}}" readonly>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-4  col-12 card-table ">
            <div class="card card-gradient-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class=" font-weight-bold text-white text-uppercase mb-1">
                                <h5> DOANH SỐ CÁ NHÂN</h5>
                                <p class="ms-card-change">{{number_format($user->getPoint->doanhso_canhan)}} VNĐ</p>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fa-solid fa-award fa-2x text-light"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-4 col-12 card-table ">
            <div class="card card-gradient-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class=" font-weight-bold text-white text-uppercase mb-1">
                                <h5> DOANH SỐ HỆ THỐNG</h5>
                                <p class="ms-card-change">{{number_format($user->getPoint->doanhso)}} VNĐ</p>
                            </div>

                        </div>
                        <div class="col-auto">
                            <i class="fa-solid fa-globe fa-2x text-light"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Số điểm hiện tại của user -->
        <div class="col-xl-4 col-12 card-table ">
            <div class="card card-gradient-primary shadow h-100 py-2">
                <a data-toggle="modal" data-target="#model_hoa_hong_duoc_huong">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col">
                            <div class=" font-weight-bold text-white text-uppercase mb-1">
                                <h5> Hoa hồng được hưởng</h5>
                                <p class="ms-card-change pb-3">{{number_format($user->getPoint->point)}} VNĐ</p>
                            </div>

                        </div>
                        <div class="col-auto mb-4">
                            <i class="fa-solid fa-atom fa-2x text-light"></i>
                        </div>
                    </div>
                </div>
                </a>
            </div>
        </div>

        <!-- Số nhóm hiện tại -->
        <div class="col-xl-4 col-12 card-table ">
            <div class="card card-gradient-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col">
                            <div class=" font-weight-bold text-white text-uppercase mb-1">
                                <h5>Tổng đội nhóm</h5>
                                <p class="ms-card-change pb-3">{{$soluong_f1}} nhóm</p>
                            </div>

                        </div>
                        <div class="col-auto mb-4">
                            <i class="fa-solid fa-users fa-2x text-light"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Số nhóm đủ tiêu chuẩn để nhận thưởng -->
        <div class="col-xl-4 col-12 card-table ">
            <div class="card card-gradient-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col">
                            <div class=" font-weight-bold text-white text-uppercase mb-1">
                                <h5>Nhóm đạt chuẩn</h5>
                                <p class="ms-card-change pb-3">{{$so_nhom_du_dieu_kien_doi_thuong}} nhóm</p>
                            </div>

                        </div>
                        <div class="col-auto mb-4">
                            <i class="fa-solid fa-circle-check fa-2x text-light"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<!----------------------------- Đổi thưởng lấy xe máy ---------------->    
    <div class="row">
        <div class="col-12">
            <div class="product-items">
                <div class="row">
                    <div class="col-12 col-md-6">
                        <h3 class="text-dark text-uppercase text-center">
                            <i class="fa fa-star ic_star"></i>
                            <span>Top doanh số nhóm</span>
                            <i class="fa fa-star ic_star"></i>
                        </h3>
                        @foreach ($list_doanhso as $list)
                        <div class="row" style="border: 1px solid #ff6a6a; border-radius: 5px; padding: 10px; margin: 0;">  
                            <div class="col-6">
                                <p class="text-dark text-left m-0"
                                    style="font-size: 20px">
                                    Nhóm: {{ DB::table('users')->where('id',$list->user_id)->first()->username }}
                                </p>
                            </div>
                            <div class="col-6">
                                <p class="text-dark text-right m-0"
                                    style="font-size: 20px">
                                    {{number_format($list->doanhso+$list->doanhso_canhan)}} VND</p>
                            </div>
                        </div>
                        <p> </p>
                        @endforeach
                    </div>

                    <div class="col-12 col-md-6">
                        <div class="row">
                        @foreach ( $points as $point)
                        <div class=" col-12 col-md-12 ">
                            <div class="box-product">
                                <div class="row">
                                    <div class="col-lg-8">
                                        <a title="{{$point->name}}">
                                        <img src="{{url('public/',$point->image)}}" ></a>
                                    </div>
                                    <div class="col-lg-4 text-lg-left mt-lg-0 mt-md-4 ">
                                        <h2 class="text-center m-0 text-uppercase"><a>{{$point->name}}</a></h2>
                                        <div class="mg-30" style="margin-top: 5px">
                                            <p class="text-center">
                                                <span class="label label-success" style="font-size: 14px" name="point">
                                                    {{number_format($point->points)}} VNĐ</span>
                                            </p>
                                        </div>
                                        <div class="mg-10">
                                            <a href="{{url('/promotion')}}/{{$point->points}}"
                                                class="btn btn-primary btn-sm text-uppercase" style="width:100%">Đổi {{$point->name}}</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!----------------------------- End Đổi thưởng lấy xe máy ---------------->    
</div>

<!-- Modal show tiền hoa hồng đã được chuyển khoản -->
<div class="modal fade" id="model_hoa_hong_duoc_huong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document" style="margin-top: 200px;">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-uppercase" id="exampleModalLabel">Hoa hồng được hưởng</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p class="text-dark m-0">Tổng hoa hồng <span class="text-danger">
                {{number_format($user->getPoint->point)}} </span>VNĐ</p>
                <p class="text-dark m-0">Đã nhận <span class="text-danger">
                {{number_format($user->getPoint->chuyenkhoan_hoahong)}} </span> VNĐ</p>
                <p class="text-dark m-0">Còn lại <span class="text-danger">
                {{number_format($user->getPoint->point-$user->getPoint->chuyenkhoan_hoahong)}} </span> VNĐ</p>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->
@endsection

@push('scripts')
<script>
    function copyFunct() {
        /* Get the text field */
        var copyText = document.getElementById("copyInput");

        /* Select the text field */
        copyText.select();
        copyText.setSelectionRange(0, 99999); /* For mobile devices */

        /* Copy the text inside the text field */
        navigator.clipboard.writeText(copyText.value);

        /* Alert the copied text */
        alert("Đã copy: " + copyText.value);
    }
</script>
@endpush